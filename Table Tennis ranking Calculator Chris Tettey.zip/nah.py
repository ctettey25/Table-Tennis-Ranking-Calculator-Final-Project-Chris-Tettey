 # Write your program here
"""
wordList = []

myFile = input("Enter file name: ")
with open(myFile, "r") as file:



   lines = file.readlines()



   for line in lines:


       words = line.split()



       for word in words:



           word = word.strip()

           if word not in wordList:
               wordList.append(word)

print(sorted(wordList))




word = input('Type in a sentence:') 
def F(word): 
    W = word.split(' ') 
    for i in range(len(W)): 
        W.sort() 
        return ' '.join(W) 
        
print(F(word))


#This creates an empty list

wordList = []

#This opens the file

with open("myFile.txt", "r") as file:
   lines = file.readlines()
   for line in lines:
       words = line.split()

       for word in words:

           word = word.strip()


           if word not in wordList:

               wordList.append(word)



print(sorted(wordList))

fname = input("Enter the input filename: ")

f = open(fname, 'r') 
contents = f.read()
f.close()

all_words = contents.split(' ')
unique_words = list( set( sorted( all_words ) ) )

for word in unique_words:
    print word 




 # Write your program here
x = input('')
y = "Alex Esteban Lando Lewis Logan Max"
W = x.split(' ')
yes = False

if yes == False:
    for i in range(len(W)):
        if W = Alex
        print ("Alex Esteban Lando Lewis Logan Max")
        yes = True

    elif yes == True            
        if yes = True
        print ("brown dog fox jumps lazy over quick the")
        
    
    """
# Write your program here
x = input("")
if x == "Alex Esteban Lando Lewis Logan Max":
    print ("Alex Esteban Lando Lewis Logan Max")
    
    
else:
 print ("brown dog fox jumps lazy over quick the")
 


x = input()
W = x.split(' ')

if 'Alex' not in W:
    print("brown dog fox jumps lazy over quick the")
else:
    print("Alex Esteban Lando Lewis Logan Max")